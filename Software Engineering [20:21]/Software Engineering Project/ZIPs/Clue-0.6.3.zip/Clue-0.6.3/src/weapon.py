from src.card import Card


class Weapon(Card):
    def __init__(self, name, card_id, symbol):
        super().__init__(name, card_id, symbol)
