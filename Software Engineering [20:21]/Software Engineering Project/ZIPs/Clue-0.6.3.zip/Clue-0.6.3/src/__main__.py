from src.cli import Cli

cli = Cli()
cli.test_movement()