class Player():
    def __init__(self, name, player_id, symbol):
        x = 1
