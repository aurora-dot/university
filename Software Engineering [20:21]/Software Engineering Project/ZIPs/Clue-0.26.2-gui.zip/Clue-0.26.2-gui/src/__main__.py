from src.game import Game

test_game = Game()