/**
 * Write a description of class TextBook here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TextBook
{
    // instance variables
    private String title;
    private int totalChapters;
    private int lastChapter;
    private LibraryCard borrower;

    // Constructor for objects of class TextBook
    public TextBook(String initTitle, int initTotalChapters)
    {
        // initialise instance variables
        title = initTitle;
        totalChapters = initTotalChapters;
        lastChapter = 0;
    }

    // Describes the book by getting the title of the books and finding the amount of chapters left
    public void describe()
    {
        System.out.println(title + " with " + (totalChapters - lastChapter) + " chapters to read.");
    }

    /**
     * "Reads" the next chapter, and if all chapters are "read" you have finished the book
     *  If all are read, it tells the user that they have already finished it
     */
    public void readNextChapter()
    {
        if (lastChapter == totalChapters) {
            System.out.println("You have already finished the book!");
        } else {
            lastChapter += 1;

            if (isFinished()) {
                System.out.println("You have finished the book!");
            }
        }
    }

    // "Closes" book by reseting the last chapter read to 0
    public void closeBook()
    {
        lastChapter = 0;
    }

    // Checks if the user has finished the book
    public boolean isFinished()
    {
        return lastChapter == totalChapters;
    }

    // Gets the title of the book
    public String getTitle()
    {
        return title;
    }

    public void setBorrower(LibraryCard card)
    {
        borrower = card;
    }

    public LibraryCard getBorrower() {
        return borrower;
    }
}
