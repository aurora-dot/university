/**
 * Write a description of class Library here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Library
{
    // instance variables - replace the example below with your own
    private TextBook[] bookShelf;
    private int nextBook;
    private int totalBorrowers;
    private int totalBooks;

    /**
     * Constructor for objects of class Library
     * Fills the bookshelf with text books, all have 10 chapters with a unique name
     */
    public Library(int initTotalBooks)
    {
        totalBorrowers = 0;
        totalBooks = initTotalBooks;
        nextBook = 0;

        bookShelf = new TextBook[totalBooks];
        for (int x = 0; x < totalBooks; x += 1) {
            bookShelf[x] = new TextBook("TextBook #" + (x + 1), 10);
        }
    }

    // Simply makes a new unique card object
    public LibraryCard issueCard()
    {
        LibraryCard newCard = new LibraryCard(5, totalBorrowers);
        totalBorrowers += 1;
        return newCard;
    }

    /**
     * Used to borrow a book, checks if card exists or is valid, and if there are books in the library
     * if true remove from bookshelf and give to user swipe the card to add it and add 1 to nextBook pointer
     * If not true with any of those statemts, return null and print why the error happened
    */
    public TextBook borrowBook(LibraryCard card)
    {
        if (card == null) {
            System.out.println("Recieved no card.");
            return null;

        } else if (nextBook == totalBooks) {
            System.out.println("No more books in the library.");
            return null;

        } else if (card.expired()) {
            System.out.println("Your card is expired.");
            return null;

        } else {
            TextBook borrowedBook = bookShelf[nextBook];
            bookShelf[nextBook] = null;
            nextBook += 1;

            card.swipe(borrowedBook);
            System.out.println("You have borrowed a book!");

            return borrowedBook;
        }
    }

    /**
     * Returns book the the library adding it back to the bookshelf array. If already full it doesn't do this.
     * If it wasn't taken out, no need to return it
     * otherwise, add to bookshelf and swipe card
     */
    public void returnBook(TextBook book)
    {
        if (nextBook == totalBooks) {
            System.out.println("Library full.");

        } else if (book.getBorrower() == null) {
            System.out.println("Book wasn't taken out, no need to return.");

        } else {
            LibraryCard card = book.getBorrower();
            card.swipe(book);
            nextBook -= 1;
            bookShelf[nextBook] = book;
            System.out.println("Returned book");
        }
    }
}
