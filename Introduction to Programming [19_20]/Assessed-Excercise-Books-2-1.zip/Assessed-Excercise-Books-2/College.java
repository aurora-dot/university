import java.util.ArrayList;
import java.util.Random;

/**
 * A simulation of a college, which students are generated and study at a library until they have finished their studies.
 *
 * @author Ethan Pannell
 * @version 1.0.0
 */

public class College
{
    private ArrayList<Student> students;
    private Library library;
    private Random rand;

    /**
     * Runs on start, checks if the user inputted any valid values, creates a college with users input and runs the college for number of steps.
     * 
     * @param  args  Used to get the users input in the command line.
     */
    public static void main(String[] args)
    {
        int studentNum = 10;
        int textNum = 15;
        int stepNum = 100;
        int len = args.length;

        if (len == 0) { System.out.println("Error: Inputted no or wrong amount of parameters, using defaults\n"); }
        else {  
            if (len >= 1) { studentNum = Integer.parseInt(args[0]); }
            if (len >= 2) { textNum = Integer.parseInt(args[1]); }
            if (len >= 3) { stepNum = Integer.parseInt(args[2]); }
            if (len > 3) { System.out.println("Error: Too many inputs given, using first three.\n"); }
        }

        College college = new College(studentNum, textNum);
        college.runCollege(stepNum);
    }

    /**
     * Constructor for objects of class College, initialises instance variables and generates students for the college.
     * 
     * @param  numStudents  The amount of students in the college.
     * @param  numTextbooks  The amount of textbooks in the colleges library.
     */
    public College(int numStudents, int numTextbooks)
    {
        // initialise instance variables
        library = new Library(numTextbooks);
        students = new ArrayList<Student>();
        rand = new Random();

        for(int i = 0; i < numStudents; i++) {
            Student tempStu = new Student("Student" + i, library);
            students.add(tempStu);
        }
    }

    /**
     * Makes a random student study if they have any students in the college and if the students have finished their studies.
     * 
     * If the college has no students, it prints appropriate text,
     * if a student is finished their studies they are removed,
     * otherwise the student studies
     */
    private void nextStep()
    {
        if (students.size() == 0) {
            System.out.println("Everything has gone quiet.");

        } else {
            int stuIndex = rand.nextInt(students.size());
            Student stuTemp = students.get(stuIndex);

            if (stuTemp.finishedStudies()) {
                students.remove(stuIndex);
                System.out.println("The student has graduated and left the college.");

            } else {
                stuTemp.study();
            }
        }
    }

    /**
     * Runs the college simulation to nSteps, showing the step number and the description of the college.
     *
     * @param  nSteps  The amount of steps the college runs
     */
    public void runCollege(int nSteps)
    {
        for (int i = 0; i < nSteps; i++) {
            System.out.println("Step " + (i + 1));
            describe();
            nextStep();
            System.out.println();
        }
    }

    /**
     * Describes the status of the college
     */
    public void describe()
    {
        System.out.println("The college currently has " + students.size() + " hard working student's.");
        library.describe();
    }
}
