import java.util.ArrayList;
import java.util.Random;

/**
 * A simulation of a college, which students are generated and study at a library until they have finished their studies.
 *
 * @author Ethan Pannell
 * @version 1.0.0
 */

public class College
{
    /**
     * The students of the college.
     */
    ArrayList<Student> students;

    /**
     * The college library.
     */
    Library library;

    /**
     * A random int generator to select a student at random.
     */
    Random rand;

    public static void main(String[] args)
    {
        if (args.length == 0) {
            System.out.println("Nothing inputted, defaults used.\n");
            College college = new College(10, 15);
            college.runCollege(45);
            
        } else if (!(args[0].matches("\\d+") || args[0].matches("\\d+") || args[0].matches("\\d+"))) {
            System.out.println("Inputted a string not a int.");

        } else {
            College college = new College(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
            college.runCollege(Integer.parseInt(args[2]));
        }
    }
    
    /**
     * Constructor for objects of class College, initialises instance variables and generates students for the college.
     * 
     * @param  numStudents  The amount of students in the college.
     * @param  numTextbooks  The amount of textbooks in the colleges library.
     */
    public College(int numStudents, int numTextbooks)
    {
        // initialise instance variables
        library = new Library(numTextbooks);
        students = new ArrayList<Student>();
        rand = new Random();

        for(int i = 0; i < numStudents; i++) {
            Student tempStu = new Student("Student" + i, library);
            students.add(tempStu);
        }
    }

    /**
     * Makes a random student study if they have any students in the college and if the students have finished their studies.
     * 
     * If the college has no students, it prints appropriate text,
     * if a student is finished their studies they are removed,
     * otherwise the student studies
     */
    private void nextStep()
    {
        if (students.size() == 0) {
            System.out.println("Everything has gone quiet.");

        } else {
            int stuIndex = rand.nextInt(students.size());
            Student stuTemp = students.get(stuIndex);

            if (stuTemp.finishedStudies()) {
                students.remove(stuIndex);
                System.out.println("The student has graduated and left the college.");

            } else {
                stuTemp.study();
            }
        }
    }

    /**
     * Runs the college simulation to nSteps, showing the step number and the description of the college.
     *
     * @param  nSteps  The amount of steps the college runs
     */
    public void runCollege(int nSteps)
    {
        for (int i = 0; i < nSteps; i++) {
            System.out.println("Step " + (i + 1));
            describe();
            nextStep();
            System.out.println();
        }
    }

    /**
     * Describes the status of the college
     */
    public void describe()
    {
        System.out.println("The college currently has " + students.size() + " hard working student's.");
        library.describe();
    }
}
