
/**
 * Studies at a college, studies books and finishes their studies once all books are read for their library card.
 *
 * @author Ethan Pannell
 * @version 1.0.0
 */

public class Student
{
    /**
     * The name of the student.
     */
    String name;

    /**
     * The library the student goes to.
     */
    Library library;

    /**
     * The student's library card.
     */
    LibraryCard card;

    /**
     * The current book the student has.
     */
    TextBook book;

    /**
     * Constructor for objects of class Student
     *
     * @param initName  The name of the student
     * @param initLibrary  The library the student uses
     */
    public Student(String initName, Library initLibrary)
    {
        // initialise instance variables
        name = initName;
        library = initLibrary;
        card = library.issueCard();
        book = null;

    }

    /**
     * Checks if the student has finished their studies.
     *
     * @return  The boolean value of if they dont have a book and their card is expired.
     */
    public boolean finishedStudies()
    {
        return (book == null && card.expired());
    }

    /**
     * Student studies by taking out books, reading them and putting them back.
     *
     * Student takes out a book if none taken out. If they have a book read a chapter, when they are finished they
     * return the book to the library.
     */
    public void study()
    {
        if (book == null) {
            book = library.borrowBook(card);

        } else if (!(book.isFinished())) {
            book.readNextChapter();

        } else {
            book.closeBook();
            library.returnBook(book);
            book = null;
        }
    }

    /**
     * Describes Students progress on their card if no book, or their book.
     *
     * Prints out the students name, if they don't have any borrowed books, prints out their card details, otherwise
     * prints out book details and prints if the book is finished or not.
     */
    public void describe()
    {
        // Prints students name
        System.out.print("Student " + name + " has");

        if (book == null) {
            // Print how many books left until expired, \33 is to go back one line so the next line prints on the line
            // which was just printed.
            System.out.print("n't got any borrowed books. ");
            card.describe();

        } else {
            // print s description if book
            System.out.print(" the book: ");
            book.describe();

            if (book.isFinished()) {
                // print the book is finished with no chapters left
                System.out.println("The book is finished.");

            }
        }
    }
}