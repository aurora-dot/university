
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class CollegeTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class CollegeTest
{
    /**
     * Default constructor for test class CollegeTest
     */
    public CollegeTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void Main_StringInputted()
    {
        String[] str = {"hi", "1", "1"};
        College.main(str);
    }

    @Test
    public void Main_IntInputted()
    {
        String[] str = {"5", "10", "75"};
        College.main(str);
    }

    @Test
    public void Main_NothingInputted()
    {
        String[] str = {};
        College.main(str);
    }

    @Test
    public void runCollegeUntilQuiet()
    {
        College college1 = new College(1, 10);
        college1.runCollege(37);
    }
    
    @Test
    public void describe()
    {
        College college1 = new College(1, 10);
        college1.describe();
    }
}


