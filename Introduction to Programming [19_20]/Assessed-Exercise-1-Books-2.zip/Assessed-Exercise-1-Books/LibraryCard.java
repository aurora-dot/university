/**
 * Write a description of class LibraryCard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LibraryCard
{
    // instance variables
    private int borrowLimit;
    private int totalBorrowed;
    private String cardRef;

    // Constructor for objects of class LibraryCard
    public LibraryCard(int initLimit, int initRefNum)
    {
        borrowLimit = initLimit;
        totalBorrowed = 0;
        cardRef = "cardID " + initRefNum;
    }

    /**
     * Used to either add or remove a book from the users amount
     * The if statement is adding a book, while the else is removing and resetting the book, removing the owner
     */
    public void swipe(TextBook book)
    {
        if (book.getBorrower() == null) {
            totalBorrowed += 1;
            book.setBorrower(this);
        } else {
            totalBorrowed -= 1;
            book.setBorrower(null);
        }
    }

    // Prints out the card ref and how many books the user can borrow
    public void describe()
    {
        System.out.println("Library card '" + cardRef + "' with " + (borrowLimit - totalBorrowed) + " books left");
    }

    // Checks if the card is expired or not depending if max amount of books are borrowed
    public boolean expired()
    {
        return borrowLimit == totalBorrowed;
    }

    // Gets the card reference
    public String getCardRef()
    {
        return cardRef;
    }
}