This is a python application which has been turned into a package using a `pyproject.toml` file in the source directory.
The source code directory is `KR-Checkers-main` within the folder this readme is.

Steps to running:
- Open up your CLI, cd into the source code directory `KR-Checkers-main`
- Run `python -m pip install .`
    - If an error outputs about the python Script directory not being on path, copy the outputted path to the clipboard (this happens on lab machines)
        - An example of the path outputted would be: ` WARNING: The script PlayCheckers.exe is installed in 'C:\Users\XXX000\AppData\Roaming\Python\Python36\Scripts' which is not on PATH.`
- Next if you were given an error, paste the path into the console and append `PlayCheckers` to the end of the path and execute, if no error about the path was given, you can simply run `PlayCheckers`
    - An example of the path if the error happens is: `C:\Users\XXX000\AppData\Roaming\Python\Python36\Scripts\PlayCheckers`

A more in-depth README.md is within the source code directory however it is relative to that directory rather than this one.

Thank you!
